fx_version 'cerulean'
game 'gta5'
description 'Example map for hypnonema'

this_is_a_map 'yes'
data_file 'DLC_ITYP_REQUEST' 'stream/v_hypnonema.ytyp'